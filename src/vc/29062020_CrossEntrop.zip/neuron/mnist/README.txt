These are source files that refer to MNIST problem.

mnist_loader is original loader with one added function.
It returns ndarray instead tuples

stepik_original.py is network copied from 
http://neuralnetworksanddeeplearning.com/

network_standard