activation_function.py - sigmoid, sigmoid_prime

choice.py 
I would advise to skip this step and charge the network while creation


gradient.py
curiosity file with analytical and numerical gradiend computation

network.py
MAIN FILE

regnetwork
Inherited network class with regularization

Target_functions - J_quadratic, J_quadratic_derivative.
Coming soon... J_cross_entropy